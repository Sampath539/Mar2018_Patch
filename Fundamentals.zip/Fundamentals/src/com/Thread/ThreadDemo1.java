package com.Thread;

public class ThreadDemo1 {

	public static void main(String[] args) {	//Main Thread
		MyThread1 t = new MyThread1();		//Thread instantiation	till this point only 1 thread is running that is main
		t.start();							//Here 2 threads will run main and MyThread- because we started MyThread--Automatically run() will execute
		//t.start() vs t.run() 	If we call t.start() a separate  Thread will create. If we run t.run() then just like method it will run
					//(Thread Scheduler)There is no guarantee that which Thread will be going to run first.. We will get mixed output 
			System.out.println("Main Thread");
		

	}

}

class MyThread1 extends Thread{
	public void run() {								//Overriding the run()--So it is already defined in Thread class
		
			System.out.println("run Thread");
		
	}
	
	
	//If we override start() then overrided method will execute and run() won't execute--o/p start method Main Thread
	public void start() {
		super.start();   			//Now super() method wll call and run method will execute	--o/p(1 of possi) run thread start method main thread
		System.out.println("Start method");
	}
}