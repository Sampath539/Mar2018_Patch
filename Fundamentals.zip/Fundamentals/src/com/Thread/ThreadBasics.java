package com.Thread;

public class ThreadBasics {

	//Flow of execution is a Thread
	//Learn Synchronization at the last
	//How many ways to define the Thread- 2 ways
	//1. By extending Thread class 2. By implement Runnable interface
	
	//The methods to prevent Thread execution
	//yield()  join() sleep()
	
	//							MultiTasking divided into 2 parts.. 
	//										|
	//							|											|
	//				Process based Multitasking 								Thread Based Multitasking(Program level)
	//(OS Level::Executing several tasks in parallel multitasking 
	//when each task has individual process),
	
	//For MultiThreading with rich API(Thread, Runnable, ThreadGroup,...)
			
	/*LIFE CYCLE OF THREAD
	 * 
	 * MyThread t = new MyThread();			t.start()						If ThreadSchedular allocates processor					if run()
	 * 		New/Born state			-----------------------Ready/Runnable----------------------------------------------Running---------------------Dead
	 * 																															method executes	
	 * 
	*/
	public static void main(String[] args) {
		

	}

}
