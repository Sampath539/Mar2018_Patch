package com.practice;

/**
 * @author Admin
 *
 */
public class Operators {

	public static void main(String[] args) {
		int m=10;
		int n=9;
		System.out.println(~2);

	}

}
/*

Operands precedence
There is no operands precedence. operands will executes from left to right

int a = m1(1) + m1(2) * m1(3) - m1(4) % m1(5) / m1(6);

first m1 methods will executes from left to right then will check for operators precedence

Operator precedence:::

Unary Operators
[] x++ x--
++x --x ~ !
new ,<type>

Arithematic operators

*,/,%
+,-

Shift Operators
>>,>>>,<<

Comparisions

<,<=,>,>=,instanceof

equality operta
==,!=

Bitwise

&,^,|

Short circuit ope

&& ||



m =10;
n=9;

01111
111100

&::
0 0 1 1
0 1 0 1
-------
0 0 0 1
	
m&n:::::

1010
1001
----
1000==8

|:::
0 0 1 1
0 1 0 1
-------
0 1 1 1

m|n::::

1010
1001
----
1011==11

~m::::

~4

	00000....0100
~4	11111....1011
2's:
1's	 0000....0100
				1
	1		 0101 ==-5
	

		 




*
*
*/